Build my personal portfolio website. I've attached a content file (portfolio_content.md) with all the real copy, experience, projects, and links to use — pull directly from it rather than inventing placeholder content.

DESIGN DIRECTION
Keep the terminal/CLI aesthetic I already have: monospace type, command-palette style navigation (e.g. /home, /experience, /projects, /skills, /education, /contact), a "whoami" style intro block, numbered sections (01/EXPERIENCE, 04/EDUCATION etc.), status indicators like "ONLINE" and "PROCESSES RUNNING", and tag-chip labels on project cards (e.g. JAVA / OOD / SERIALIZATION). Dark background, monospace font throughout.

I want the overall feel to lean AI-focused rather than purely backend/systems — I'm an MEng Computer Science (Artificial Intelligence) student. Do this through:
- Tagline/bio copy that explicitly references AI-assisted development and AI/ML, not just "systems and interfaces" (use the bio from the content file, adjust tone slightly toward AI if needed but don't fabricate claims)
- Giving my AI/ML skills (TensorFlow, Keras, PCA) real visual prominence in the /skills section rather than burying them under general languages
- Structuring /projects with a filter/tab system (like ALL / SYSTEMS / INTERFACE) and add an AI-related tab so future AI projects have a clear home, even if it's empty for now

SECTIONS TO BUILD
- /home — hero with intro/bio from the content file
- /experience — AccelerComm (keep this concise, not a week-by-week breakdown — just the short bullet version from the content file), Freelance Web Developer, LetUsBloom
- /projects — Java Training School Simulation, JavaFX Noughts & Crosses (both with their tag chips as in the content file). Also add entries for the two past web projects — Impulse and LetUsBloom — using the screenshots I'll provide, treated as design/web work rather than code projects
- /skills — full skills list from the content file, with AI/ML tools given visual priority
- /education — University of Southampton (MEng CS with AI) and ONCAMPUS foundation year. Just say "On track for a 2:1" — do not include a specific percentage/average
- /contact — include ALL of: resume/CV download (PDF), a contact form, and direct email + LinkedIn links

CONTENT RULES
- Do not include Spendwise, Pulse, or Freshers Rescue anywhere — they're unfinished
- Do not include Subway or Beity Lebanese Restaurant as work experience
- Do not reference or copy my old portfolio (Shlok_OS) in any way
- Interests section (if included) should only mention DJing (Bollywood/Punjabi) and cricket — no streetwear
- Use my actual LinkedIn description verbatim for the Indian Society Head of Events role if that section is included
- Keep the AccelerComm write-up short and high-impact, not a full week-by-week log

Ask me for the resume PDF, headshot photo, and project screenshots if they're not already available in the project files.
