# Portfolio Content — Shlok Navin Panjabi

*Compiled reference doc for the new engineering blueprint / spec-sheet themed portfolio (Replit build).*
*Note: Spendwise, Pulse, and Freshers Rescue are excluded — unfinished / in-progress. Add once complete.*

---

## Contact / Links
- Location: Southampton, England
- Phone: +44 7554 739930
- Email: shlokpanjabi.work@gmail.com
- LinkedIn: linkedin.com/in/shlok-panjabi

---

## Profile / Bio
First-year MEng Computer Science (Artificial Intelligence) student at the University of Southampton. Interested in AI-assisted development workflows, building scalable software, and refactoring AI-generated code to production quality. Currently exploring software engineering and AI broadly — not narrowly identifying with any single track.

---

## Education
**University of Southampton** — Sep 2025–Present
MEng Computer Science (Artificial Intelligence)
- On track for a 2:1
- Core modules: Algorithmics, Data Management (SQL/Relational), Computer Systems, Networks & Security
- Programming I & II — advanced Java and Python proficiency
- Applied Mathematics I & II — logical frameworks underpinning AI/ML

**ONCAMPUS Southampton** — Sep 2024–May 2025
University Foundation Programme
- Mathematics: A*, Physics: A*, Skills for Science: A*

---

## Professional Experience

### AccelerComm — System Test Summer Intern
*9 weeks, Southampton Science Park*

- Built Python test automation for RF equipment using PyVISA and SCPI, writing 3GPP-based test cases from scratch — including deliverable-ready cases sent to customers
- Independently brought up an NXP LX2160 DUT from the ground up (hardware assembly + full software bring-up: firmware, bootloader/kernel config, drivers, networking), now used as a spare test DUT
- Figured out setup for an unfamiliar Keysight instrument with no existing playbook, with minimal guidance

**Tools/Stack:** Python, PyVISA, SCPI, Keysight test equipment, NXP LX2160, Ubuntu, 3GPP standards

### Web Developer & Designer (Freelance) — Aug 2024–Present
- Delivered two custom web development projects end-to-end, from design through deployment, to specific client requirements

### LetUsBloom — Head of Technology (Remote) — Aug 2024–Mar 2025
- Managed organization website architecture, ensuring usability and structural integrity across digital initiatives

---

## Leadership & Volunteering

### Head of Events — UoS Indian Society (2026/27)
*Jun 2026–Present · 3 mos · Hybrid*

As Head of Events, I am responsible for planning and delivering the Indian Society's flagship events while working closely with the committee to create engaging experiences for our members. I oversee the event planning process from start to finish, collaborate with internal and external stakeholders, and contribute to new initiatives that celebrate Indian culture and strengthen our community on campus.

### SOTSEF Science & Engineering Family Day — Technical Volunteer — Mar 2026, Southampton
- Facilitated technical demonstrations and supervised electronic construction workshops for 5,000 visitors
- Contributed to a high event satisfaction rating

---

## Academic / Personal Projects

### Java Training School Simulation — 2025
- Comprehensive school management simulation with a focus on Object-Oriented Design (OOD) principles
- Implemented file serialization to persist student/staff data with integrity across sessions

### JavaFX Noughts & Crosses — 2025
- GUI-based game built with the Model-View-Controller (MVC) architectural pattern
- Used JavaFX UI binding to sync game state with the graphical interface for responsive interaction

### Past Web Projects (not currently live)
- **Impulse** — Event website built for Podar World College's "Impulse" event ("Igniting Passion, Inspiring Brilliance!"). Included a landing/presentation page and a photo gallery section documenting the event. Screenshots available.
  - Recommended visuals: title/hero screen, gallery section
- **LetUsBloom** — Website built for LetUsBloom during Head of Technology role. Landing page ("Where Creativity Blossoms"), navigation menu, and an "Our Team" page featuring member profiles. Screenshots available.
  - Recommended visuals: "BLOOM" landing hero, "Our Team" page

---

## Skills

**Languages/Programming:** Java, Python, C, SQL
**Systems:** Unix/Linux command-line environments
**Design/Web:** Figma, Wix
**AI/ML:** TensorFlow, Keras, PCA (dimensionality reduction)
**Hardware/RF (from internship):** PyVISA, SCPI, Keysight test equipment, DUT bring-up (firmware/bootloader/drivers)
**Spoken Languages:** English (IELTS 7.5), Hindi, French

**Other interests (for personality/creative sections):** DJing (Bollywood & Punjabi music, runs a DJ mix upload account), cricket

---

## Photo
- A current headshot photo is available and can be used for the portfolio (e.g. hero section / about page)

## Call to Action
- Include all: resume download (PDF), contact form, and direct email/LinkedIn links

## Notes for portfolio build
- Keep Spendwise, Pulse, and Freshers Rescue OUT until finished — add them as new "spec sheets" once shipped
- No reference to the old Shlok_OS portfolio (design or content) — it's being retired
- Subway and Beity Lebanese Restaurant deliberately excluded — not aligned with degree/skills
- Aesthetic direction (per Shlok's brief): engineering blueprint / spec-sheet — blueprint navy palette, faint grid background, schematic-style accents
- Consider treating each project/experience like a technical "spec sheet" or schematic callout to match the theme (e.g. AccelerComm entry as a system diagram with labeled instruments/stack)
